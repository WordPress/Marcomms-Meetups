# ZIPS
These are the pormotional packs as zips,  keep all zips in the root of this folder only please.